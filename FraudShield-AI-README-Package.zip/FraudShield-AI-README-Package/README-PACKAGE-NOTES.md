# README package contents

Copy `README.md` into the root of your FraudShield AI repository.

Copy the `docs/images/` folder into the repository so that the banner and architecture diagram paths in the README resolve.

The banner is an illustrative project banner, not a screenshot of the running application.
Capture screenshots of your actual website and add them to `docs/images/` using the filenames listed in the README's Screenshots section.

Before publishing, restore the missing `frontend/src/` and `frontend/package.json` from your original frontend development workspace if they exist. The uploaded archive contained the compiled frontend build but not those source files.
