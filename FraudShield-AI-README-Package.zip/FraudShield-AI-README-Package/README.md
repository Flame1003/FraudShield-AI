<p align="center">
  <img src="docs/images/project-banner.png" alt="FraudShield AI — Credit Card Fraud Detection" width="100%">
</p>

<h1 align="center">FraudShield AI</h1>
<p align="center"><strong>Credit Card Fraud Detection Using Machine Learning</strong></p>
<p align="center">
  An educational full-stack application that explores imbalanced transaction classification,
  compares machine-learning models, and predicts potentially fraudulent transactions.
</p>

<p align="center">
  <img alt="Python" src="https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white">
  <img alt="FastAPI" src="https://img.shields.io/badge/API-FastAPI-009688?logo=fastapi&logoColor=white">
  <img alt="React" src="https://img.shields.io/badge/Frontend-React-61DAFB?logo=react&logoColor=black">
  <img alt="Scikit--learn" src="https://img.shields.io/badge/ML-Scikit--learn-F7931E?logo=scikitlearn&logoColor=white">
  <img alt="Pandas" src="https://img.shields.io/badge/Data-Pandas-150458?logo=pandas&logoColor=white">
  <img alt="License" src="https://img.shields.io/badge/License-Choose%20before%20publishing-lightgrey">
</p>

---

## Table of Contents

- [1. Project Overview](#1-project-overview)
- [2. Problem Statement](#2-problem-statement)
- [3. Project Objectives](#3-project-objectives)
- [4. Key Features](#4-key-features)
- [5. Technology Stack](#5-technology-stack)
- [6. Dataset](#6-dataset)
- [7. Machine Learning Workflow](#7-machine-learning-workflow)
- [8. Algorithms Implemented](#8-algorithms-implemented)
- [9. Model Evaluation Results](#9-model-evaluation-results)
- [10. System Architecture](#10-system-architecture)
- [11. Project Structure](#11-project-structure)
- [12. Installation and Setup](#12-installation-and-setup)
- [13. Running the Application](#13-running-the-application)
- [14. API Reference](#14-api-reference)
- [15. How to Use FraudShield AI](#15-how-to-use-fraudshield-ai)
- [16. Screenshots](#16-screenshots)
- [17. Important Notes and Limitations](#17-important-notes-and-limitations)
- [18. Future Improvements](#18-future-improvements)
- [19. Academic Context](#19-academic-context)
- [20. Acknowledgements](#20-acknowledgements)

---

## 1. Project Overview

**FraudShield AI** is a machine-learning-based credit card fraud detection project. It demonstrates how supervised classification algorithms can be trained to distinguish between legitimate and fraudulent transactions in a highly imbalanced dataset.

The project combines a Python machine-learning pipeline with a FastAPI backend and a React-based user interface. The backend exposes endpoints for dataset statistics, model information, individual transaction predictions, and CSV batch predictions.

The trained classifiers assign each transaction to one of two classes:

| Class | Meaning |
|---|---|
| `0` | Legitimate transaction |
| `1` | Fraudulent transaction |

The application is intended for learning, experimentation, and demonstration. It is **not** connected to a bank, card network, payment gateway, or live transaction authorization system.

### At a glance

| Item | Project implementation |
|---|---|
| Project name | FraudShield AI |
| Project type | Full-stack machine learning application |
| ML task | Binary classification |
| Domain | Financial fraud detection |
| Dataset | European credit card transactions dataset |
| Backend | Python and FastAPI |
| Frontend build | React-based Vite application |
| Main classifiers | Decision Tree and Random Forest |
| Additional classifiers | XGBoost and LightGBM |
| Imbalance strategy | Class weighting / positive-class weighting |
| Model selection | Highest validation PR-AUC among trained models |
| Inference | Saved model and saved feature scaler |

## 2. Problem Statement

Credit card fraud detection is a challenging classification problem because fraudulent transactions are extremely rare compared with legitimate transactions.

A model can achieve very high overall accuracy simply by predicting that almost every transaction is legitimate. Such a model would be practically unhelpful because it could fail to identify the minority fraud class.

This project investigates how classical machine-learning classifiers can identify the minority class while balancing two important types of error:

- **False negative:** a fraudulent transaction is classified as legitimate.
- **False positive:** a legitimate transaction is classified as fraudulent.

The project therefore evaluates precision, recall, F1-score, ROC-AUC, and especially Precision-Recall AUC (PR-AUC), rather than relying on accuracy alone.

## 3. Project Objectives

1. Understand a real-world imbalanced binary-classification problem.
2. Inspect and validate a credit card transaction dataset.
3. Explore transaction features and class distribution.
4. Prepare the dataset for supervised learning.
5. Use stratified training, validation, and test splits.
6. Train Decision Tree and Random Forest classifiers.
7. Experiment with XGBoost and LightGBM as additional tree-based boosting models.
8. address class imbalance through model weighting.
9. Compare models using appropriate classification metrics.
10. Select a model using validation PR-AUC.
11. expose trained models through a REST API.
12. provide individual and batch prediction workflows through a web interface.

## 4. Key Features

The supplied frontend build includes the following application sections. The backend routes and bundled frontend were inspected in the uploaded project archive.

### 4.1 Dashboard

- Dataset-level transaction statistics.
- Legitimate and fraudulent class distribution.
- Fraud percentage.
- Model and evaluation summaries.
- Data visualizations.

### 4.2 Single Transaction Detection

- Enter transaction feature values.
- Select a trained model where supported by the interface.
- Submit a transaction to the prediction API.
- View the predicted class, fraud score, selected threshold, and model information.

### 4.3 Batch CSV Detection

- Upload a CSV containing transaction features.
- Validate the file type and size.
- Predict multiple rows.
- View the number of predicted fraud and legitimate transactions.
- Receive CSV-formatted prediction results.

The backend currently limits batch uploads to 20 MB and 10,000 rows. It returns up to 500 prediction objects for on-screen display while including the processed result CSV in the response.

### 4.4 ML Algorithms

Educational explanations of the implemented tree-based classification methods.

### 4.5 Model Comparison

Side-by-side model metrics, including precision, recall, F1-score, ROC-AUC, and PR-AUC.

### 4.6 Dataset Explorer

Dataset structure, feature information, class imbalance, transaction amount statistics, duplicate count, and missing-value information.

### 4.7 About and Methodology

An academic overview of the project and its machine-learning workflow.

## 5. Technology Stack

### 5.1 Machine Learning and Data Processing

| Technology | Purpose in this project |
|---|---|
| Python | Main programming language for ML and backend |
| Pandas | Loading, inspecting, and processing CSV data |
| NumPy | Numerical arrays and calculations |
| Scikit-learn | Preprocessing, splitting, classifiers, and evaluation metrics |
| XGBoost | Gradient-boosted tree classifier |
| LightGBM | Gradient-boosted tree classifier |
| Joblib | Saving and loading trained models and preprocessing artifacts |

### 5.2 Backend

| Technology | Purpose |
|---|---|
| FastAPI | REST API framework |
| Pydantic | Request validation and response schemas |
| Uvicorn | Local ASGI application server |
| python-multipart | Multipart file upload support |

### 5.3 Frontend

The supplied production bundle identifies a React application built with Vite and includes bundled usage of React Router, Recharts, and Lucide React. The original frontend source directory and package manifest were not present in the uploaded archive, so exact frontend dependency versions cannot be confirmed from that archive.

| Technology | Purpose |
|---|---|
| React | Component-based user interface |
| Vite | Frontend build tooling |
| Tailwind CSS | Styling utilities present in the compiled stylesheet |
| React Router | Navigation between application pages |
| Recharts | Data visualization |
| Lucide React | Interface icons |
| JavaScript | Frontend application logic |

## 6. Dataset

### 6.1 Dataset source

The project uses the **Credit Card Fraud Detection** dataset made available by the Machine Learning Group of Université Libre de Bruxelles (ULB).

Dataset page:

https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud

The dataset contains anonymized European cardholder transactions. It is commonly used as a benchmark for imbalanced fraud-detection classification.

### 6.2 Dataset statistics verified from the supplied CSV

| Statistic | Observed value |
|---|---:|
| Total rows before preprocessing | 284,807 |
| Total columns | 31 |
| Input features | 30 |
| Target column | `Class` |
| Legitimate transactions (`Class = 0`) | 284,315 |
| Fraudulent transactions (`Class = 1`) | 492 |
| Fraud percentage | Approximately 0.1727% |
| Missing values | 0 |
| Duplicate rows detected | 1,081 |

The supplied CSV was inspected directly. The statistics above describe the uploaded file, before the preprocessing script removes duplicate rows.

### 6.3 Dataset columns

The dataset contains:

- `Time`: seconds elapsed between a transaction and the first transaction in the dataset.
- `V1` through `V28`: anonymized features obtained using Principal Component Analysis (PCA) by the dataset creators.
- `Amount`: transaction amount.
- `Class`: target label (`0` for legitimate and `1` for fraud).

**Important:** `V1`–`V28` are transformed, anonymized numerical features. They are not ordinary customer details such as name, card number, merchant, or location. Their original business meaning is not available in this dataset.

The project uses the existing PCA-transformed features; it does not need to apply PCA to those columns again.

### 6.4 Class imbalance

The dataset is strongly imbalanced:

- Legitimate transactions: 284,315
- Fraudulent transactions: 492

Fraud accounts for only about 0.1727% of the supplied rows. This is why accuracy alone is not a sufficient measure of model quality.

### 6.5 Data cleaning

The supplied preprocessing code:

1. Loads the CSV file.
2. Checks that the required columns exist.
3. Checks that both target classes are present.
4. Removes duplicate rows.
5. Removes rows containing missing values.
6. Separates input features from the target column.

The uploaded dataset contains 1,081 duplicate rows and no missing values. After duplicate removal, 283,726 rows remain for the split recorded in the supplied training results.

## 7. Machine Learning Workflow

The ML pipeline is implemented in `backend/ml/`.

### Step 1 — Load and validate the dataset

The CSV is loaded with Pandas. The preprocessing code checks for `Time`, `Amount`, `Class`, and all 28 anonymized PCA features.

### Step 2 — Remove duplicate and missing records

Duplicate rows are removed. Rows containing missing values are dropped by the current preprocessing implementation.

### Step 3 — Separate features and target

- `X`: all feature columns except `Class`.
- `y`: the `Class` target column.

The target is not included as an input feature.

### Step 4 — Stratified data splitting

The code uses a stratified 60% / 20% / 20% split:

| Split | Rows in saved experiment | Purpose |
|---|---:|---|
| Training | 170,235 | Fit the models |
| Validation | 56,745 | Compare models and select thresholds |
| Test | 56,746 | Final evaluation of the selected model |
| **Total** | **283,726** | After duplicate removal |

Stratification preserves approximately the same class proportions across the splits.

### Step 5 — Feature scaling

The implementation uses `StandardScaler`.

The scaler is fitted only on the training split. The fitted scaler is then used to transform the validation and test splits. This prevents the scaler from learning statistics from the validation or test data.

The fitted scaler and feature names are saved for inference.

### Step 6 — Handle class imbalance

The training code uses model weighting rather than applying SMOTE:

- Decision Tree: `class_weight="balanced"`.
- Random Forest: `class_weight="balanced"`.
- LightGBM: `class_weight="balanced"`.
- XGBoost: `scale_pos_weight`, calculated from the training class distribution.

This makes the training objective account for the rare fraud class.

### Step 7 — Train classifiers

The training script fits the available model implementations and evaluates them on the validation data.

### Step 8 — Select a classification threshold

For each model that supports `predict_proba`, the training script searches thresholds from 0.01 to 0.99 and selects the threshold with the highest validation F1-score.

The selected threshold is stored with the model results.

### Step 9 — Select the best model

The model with the highest validation PR-AUC is selected.

### Step 10 — Final test evaluation

The selected model is evaluated on the test split, which is not used for model selection or threshold selection in the supplied training script.

### Step 11 — Save model artifacts

The project saves trained models, the scaler, feature names, and a JSON file containing training and evaluation information.

## 8. Algorithms Implemented

### 8.1 Decision Tree Classifier

A Decision Tree is a supervised learning algorithm that makes predictions by splitting data into smaller groups using feature-based rules.

For classification, it creates decision paths that lead to a predicted class.

**Why it is included:**

- Easy to understand.
- Provides an interpretable tree structure.
- Acts as a useful baseline classifier.
- Demonstrates how feature-based decisions can classify transactions.

The implementation uses a maximum depth of 12, a minimum leaf size of 5, balanced class weights, and a fixed random seed.

### 8.2 Random Forest Classifier

Random Forest is an ensemble-learning algorithm that trains multiple decision trees and combines their predictions.

It uses bootstrap samples and feature randomness to create a collection of trees.

**Why it is included:**

- Combines multiple decision trees.
- Often improves generalization over a single tree.
- Can model complex relationships.
- Provides a strong tree-based classification baseline.

The supplied configuration uses 100 estimators, a maximum depth of 15, a minimum leaf size of 5, balanced class weights, and parallel processing.

### 8.3 XGBoost Classifier

XGBoost is a gradient-boosted decision-tree implementation. It builds trees sequentially, with later trees working to improve errors made by earlier trees.

The project includes XGBoost as an additional comparison model. It uses `scale_pos_weight` based on the training class distribution.

### 8.4 LightGBM Classifier

LightGBM is another gradient-boosted decision-tree framework. It is designed for efficient tree boosting and can work well with structured tabular data.

The supplied implementation uses balanced class weights.

**Academic note:** XGBoost and LightGBM are classical gradient-boosted tree methods, not deep-learning neural networks. They are included as additional comparisons. The primary classical ML comparison remains Decision Tree versus Random Forest.

## 9. Model Evaluation Results

The following results are taken from the uploaded `backend/ml/models/training_results.json` file. They are the saved experiment results in the supplied project archive, not newly reproduced results.

### 9.1 Validation performance

The models are compared using their validation metrics.

| Model | Accuracy | Precision | Recall | F1-score | ROC-AUC | PR-AUC |
|---|---:|---:|---:|---:|---:|---:|
| Decision Tree | 99.8537% | 54.14% | 76.60% | 63.44% | 0.8981 | 0.5118 |
| Random Forest | 99.9577% | 88.89% | 85.11% | 86.96% | 0.9637 | 0.8667 |
| XGBoost | 99.9630% | 91.95% | 85.11% | 88.40% | 0.9763 | 0.8715 |
| LightGBM | 99.9648% | 95.12% | 82.98% | 88.64% | 0.9769 | **0.8763** |

### 9.2 Selected model

**LightGBM was selected as the best model in the saved experiment because it achieved the highest validation PR-AUC: 0.8763.**

The selection criterion is validation PR-AUC, not accuracy.

### 9.3 LightGBM final test results

The saved test metrics for the selected LightGBM model are:

| Metric | Test result |
|---|---:|
| Accuracy | 99.9489% |
| Precision | 92.31% |
| Recall | 75.79% |
| F1-score | 83.24% |
| ROC-AUC | 0.9683 |
| PR-AUC | 0.8020 |
| Decision threshold | 0.82 |

### 9.4 LightGBM test confusion matrix

| | Predicted legitimate | Predicted fraud |
|---|---:|---:|
| Actually legitimate | 56,645 (TN) | 6 (FP) |
| Actually fraud | 23 (FN) | 72 (TP) |

Where:

- **True Negative (TN):** legitimate transactions correctly identified.
- **False Positive (FP):** legitimate transactions incorrectly flagged as fraud.
- **False Negative (FN):** fraudulent transactions missed by the model.
- **True Positive (TP):** fraudulent transactions correctly identified.

The test split contained 95 fraudulent transactions. The selected model detected 72 and missed 23 at the saved threshold.

### 9.5 Understanding the metrics

| Metric | Meaning |
|---|---|
| Accuracy | Fraction of all predictions that are correct |
| Precision | Of transactions predicted as fraud, the fraction that were actually fraud |
| Recall | Of all actual fraud cases, the fraction detected |
| F1-score | Harmonic mean of precision and recall |
| ROC-AUC | Measures ranking/discrimination across thresholds using the ROC curve |
| PR-AUC | Summarizes the precision-recall trade-off across thresholds |

For this imbalanced dataset, PR-AUC and the fraud-class precision/recall trade-off are especially important.

**Results interpretation:** The saved LightGBM test result has high precision, while its recall is lower. This means the selected threshold produces relatively few false alarms but misses some fraudulent transactions. A different threshold could change that trade-off.

## 10. System Architecture

FraudShield AI has three main layers:

1. **Frontend:** presents dashboard pages, forms, charts, and batch-upload controls.
2. **Backend:** receives requests, validates input, serves dataset/model information, and coordinates predictions.
3. **Machine-learning layer:** loads the saved scaler, feature order, model, and selected threshold to generate predictions.

<p align="center">
  <img src="docs/images/architecture.svg" alt="FraudShield AI system architecture" width="100%">
</p>

### Prediction flow

1. The user submits transaction features or uploads a CSV.
2. The frontend sends an HTTP request to FastAPI.
3. FastAPI validates the request.
4. The prediction module arranges features in the saved feature order.
5. The saved `StandardScaler` transforms the input.
6. The selected trained classifier calculates a fraud score.
7. The score is compared with the selected model threshold.
8. The API returns the predicted class, score, threshold, and model information.
9. The frontend displays the result.

## 11. Project Structure

The uploaded archive contains the following main project files. Generated files such as `node_modules`, Python cache directories, and compiled frontend assets are omitted from this simplified view.

```text
rehaan ml project/
│
├── .gitignore
│
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── routes/
│   │   │   ├── dataset.py
│   │   │   ├── models.py
│   │   │   └── predict.py
│   │   └── schemas/
│   │       └── schemas.py
│   │
│   ├── ml/
│   │   ├── data/
│   │   │   └── creditcard.csv
│   │   ├── models/
│   │   │   ├── decision_tree.pkl
│   │   │   ├── random_forest.pkl
│   │   │   ├── xgboost.pkl
│   │   │   ├── lightgbm.pkl
│   │   │   ├── scaler.pkl
│   │   │   ├── feature_names.pkl
│   │   │   └── training_results.json
│   │   ├── preprocessing.py
│   │   ├── train.py
│   │   ├── evaluate.py
│   │   ├── predict.py
│   │   └── generate_dataset.py
│   │
│   ├── requirements.txt
│   └── run.py
│
└── frontend/
    ├── index.html
    └── dist/
        └── assets/
```

**Frontend source note:** The uploaded archive contains a compiled frontend build and bundled assets, but does not contain `frontend/src/` or `frontend/package.json`. Restore those source files and the package manifest from the original development workspace before presenting this repository as fully source-reproducible or attempting a fresh Vite development build.

### Important backend files

| File | Responsibility |
|---|---|
| `app/main.py` | Creates the FastAPI application and registers routers |
| `routes/dataset.py` | Dataset overview and dashboard statistics |
| `routes/models.py` | Model list, comparison, and evaluation endpoints |
| `routes/predict.py` | Single and batch prediction endpoints |
| `schemas/schemas.py` | Pydantic request and response models |
| `ml/preprocessing.py` | Dataset validation, duplicate removal, splitting, scaling |
| `ml/train.py` | Model training, threshold search, model selection, and saving |
| `ml/evaluate.py` | Loads saved results and provides evaluation/chart data |
| `ml/predict.py` | Loads saved artifacts and performs inference |
| `ml/generate_dataset.py` | Optional synthetic-data generator for development fallback |

## 12. Installation and Setup

### 12.1 Prerequisites

Install:

- Python 3.10 or later (use a version compatible with the pinned packages).
- Node.js and npm if you have restored the frontend source and package manifest.
- Git.
- Visual Studio Code (recommended).

### 12.2 Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/FraudShield-AI.git
cd FraudShield-AI
```

Replace the URL with your actual GitHub repository URL.

### 12.3 Create a Python virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Windows Command Prompt:

```cmd
python -m venv .venv
.venv\Scripts\activate
```

### 12.4 Install backend dependencies

```bash
cd backend
pip install -r requirements.txt
```

The supplied `backend/requirements.txt` pins the following packages:

- fastapi
- uvicorn
- pandas
- numpy
- scikit-learn
- joblib
- matplotlib
- seaborn
- imbalanced-learn
- xgboost
- lightgbm
- pydantic
- python-multipart

### 12.5 Download and place the dataset

Download the dataset from:

https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud

Place the extracted CSV at:

```text
backend/ml/data/creditcard.csv
```

The expected filename is exactly:

```text
creditcard.csv
```

The dataset is excluded from Git by `.gitignore` because it is large and should be downloaded separately by each user.

### 12.6 Train the models

From the repository root, with the virtual environment activated:

```bash
python backend/ml/train.py
```

This command:

1. Loads and validates the dataset.
2. Removes duplicate and missing rows.
3. Creates stratified training, validation, and test splits.
4. Fits the scaler on training data.
5. Trains the available classifiers.
6. Selects thresholds using validation F1-score.
7. Selects the best model using validation PR-AUC.
8. Evaluates the selected model on the test set.
9. Saves models and evaluation metadata.

The training process can take time, particularly for Random Forest and the boosting models.

### 12.7 Start the backend

From the repository root:

```bash
python backend/run.py
```

The API will be available at:

```text
http://localhost:8000
```

Interactive API documentation:

```text
http://localhost:8000/api/docs
```

Alternative ReDoc documentation:

```text
http://localhost:8000/api/redoc
```

## 13. Running the Application

### Backend

Start the backend:

```bash
python backend/run.py
```

### Frontend

The uploaded archive does not include the original React source or `package.json`, so a fresh `npm install` / `npm run dev` workflow cannot be verified from the supplied files.

If the original frontend source is available, restore it under `frontend/src/` and restore its `package.json`, then install dependencies and run the scripts defined by that manifest.

The supplied compiled frontend bundle calls the backend at:

```text
http://localhost:8000/api
```

The static build is located in `frontend/dist/`. It can be served by a static web server, but the frontend source and reproducible build setup should be committed before treating the repository as a complete developer-ready frontend project.

## 14. API Reference

The FastAPI application uses the `/api` prefix.

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Checks backend health |
| GET | `/api/dataset/overview` | Returns dataset overview and statistics |
| GET | `/api/dashboard/stats` | Returns dashboard statistics and model summary |
| GET | `/api/models` | Lists available trained models |
| GET | `/api/models/compare` | Returns model metrics and ROC/PR curve data |
| GET | `/api/models/evaluation` | Returns best-model and evaluation information |
| POST | `/api/predict` | Predicts one transaction |
| POST | `/api/predict/batch` | Predicts transactions from an uploaded CSV |
| GET | `/api/predict/sample` | Returns sample transactions from the dataset |

### Example health request

```bash
curl http://localhost:8000/api/health
```

### Example single prediction request

The single prediction endpoint expects the feature values used by the model. The example below is abbreviated; the actual request schema includes `Time`, `Amount`, and `V1` through `V28`.

```json
{
  "Time": 10000,
  "Amount": 149.99,
  "V1": -1.2,
  "V2": 0.5,
  "V3": -0.7,
  "model_name": "lightgbm"
}
```

For a valid request, provide all feature values expected by the trained model. The Pydantic schema defines defaults for most anonymized features, but using real dataset feature values is preferable for meaningful testing.

### Example response shape

```json
{
  "prediction": 0,
  "label": "LEGITIMATE",
  "fraud_probability": 0.0123,
  "threshold": 0.82,
  "model_used": "lightgbm",
  "display_name": "Lightgbm"
}
```

The values above illustrate the response format only; they are not a claim about a specific transaction.

### Batch prediction

`POST /api/predict/batch` accepts multipart form data:

- `file`: CSV file.
- `model_name`: optional model identifier.

The CSV must contain the model's feature columns. The backend accepts UTF-8 CSV files, with a maximum file size of 20 MB and a maximum of 10,000 rows.

## 15. How to Use FraudShield AI

1. Start the FastAPI backend.
2. Open the frontend build or restored frontend development server.
3. Open the Dashboard to view dataset and model information.
4. Open Detect Transaction to submit a feature record.
5. Use a sample transaction from the dataset when testing the prediction flow.
6. Open Batch Detection to upload a CSV containing transaction features.
7. Review the prediction labels and fraud scores.
8. Open ML Algorithms to review the implemented classifiers.
9. Open Model Comparison to compare validation metrics.
10. Open Dataset Explorer to inspect dataset statistics and class imbalance.

Because the dataset's `V1`–`V28` columns are anonymized PCA components, they are not designed as ordinary human-entered customer details. Sample dataset rows or correctly prepared feature records are the most meaningful inputs for the demonstration.

## 16. Screenshots

Add screenshots captured from the actual running application to `docs/images/`. Recommended filenames:

| Screenshot | Suggested filename |
|---|---|
| Main dashboard | `dashboard.png` |
| Single transaction form and result | `single-detection.png` |
| CSV batch upload and results | `batch-detection.png` |
| Model comparison | `model-comparison.png` |
| Dataset explorer | `dataset-explorer.png` |
| Algorithm explanation | `algorithms.png` |

After adding the screenshots, embed them here using:

```markdown
![FraudShield AI Dashboard](docs/images/dashboard.png)
```

Do not use unrelated stock dashboard images as evidence of the application's actual features. The project banner and architecture diagram included in this repository are illustrative project documentation assets; they are not application screenshots.

## 17. Important Notes and Limitations

1. **Educational project:** This application is a college-level ML demonstration, not a production banking fraud-prevention platform.
2. **Anonymized features:** `V1`–`V28` are PCA-transformed features and cannot be interpreted as normal transaction attributes.
3. **Dataset age and scope:** The benchmark dataset does not represent every modern payment environment or current fraud pattern.
4. **Class imbalance:** Fraud is a very small minority class. Accuracy must be interpreted alongside precision, recall, F1-score, and PR-AUC.
5. **Threshold trade-off:** Changing the classification threshold changes false positives and false negatives.
6. **Model generalization:** Reported metrics apply to the saved experiment and its dataset split. They do not guarantee performance on new real-world transactions.
7. **Probability interpretation:** A model's predicted probability is not automatically a calibrated real-world probability of fraud.
8. **No live authorization:** The project does not approve, decline, block, or reverse actual card payments.
9. **Artifact availability:** The `.gitignore` excludes datasets and saved model artifacts. Users must download the dataset and train the models locally before using prediction endpoints.
10. **Frontend source completeness:** The uploaded archive includes the compiled frontend build but not its source files or package manifest. Restore these before publishing a fully reproducible source repository.
11. **Synthetic dataset generator:** `generate_dataset.py` creates artificial data for development fallback. Results trained on generated data must never be presented as results from the real benchmark dataset.
12. **Batch parsing:** The current batch route skips rows with non-numeric values and reports parse errors. Review those errors rather than assuming every uploaded row was processed.

## 18. Future Improvements

Possible extensions include:

- Add automated unit and integration tests.
- Restore and publish the complete frontend source.
- Add configurable API base URLs rather than a hardcoded local backend address.
- Improve batch schema validation and explicitly report missing feature columns.
- Add downloadable model evaluation reports.
- Add feature importance visualizations.
- Add decision-threshold comparison controls.
- Add model versioning and experiment tracking.
- Add a reproducible environment file and CI workflow.
- Evaluate on newer or time-separated transaction datasets.
- Add probability calibration analysis.
- Improve accessibility and deployment documentation.

These are potential future enhancements, not claims that they are already implemented.

## 19. Academic Context

This project demonstrates concepts from a traditional Machine Learning course:

- Supervised learning.
- Binary classification.
- Decision Trees.
- Ensemble learning.
- Random Forest.
- Gradient boosting.
- Data preprocessing.
- Feature scaling.
- Stratified train/validation/test splitting.
- Class imbalance.
- Class weighting.
- Confusion matrix.
- Precision, recall, and F1-score.
- ROC-AUC and PR-AUC.
- Classification threshold selection.
- Model comparison and evaluation.
- REST API integration.

### Suggested viva explanation

> "My project, FraudShield AI, is a credit card fraud detection application built using Machine Learning. The dataset contains a highly imbalanced distribution, where fraudulent transactions form only a very small percentage of all transactions. I preprocess the dataset, remove duplicate records, split it into training, validation, and testing sets using stratified sampling, and apply StandardScaler fitted only on the training data. I train Decision Tree and Random Forest models, and also compare XGBoost and LightGBM. I use class weighting to address class imbalance and compare the models using precision, recall, F1-score, ROC-AUC, and PR-AUC. The selected model is exposed through a FastAPI backend and can be used through a React-based web interface for single and batch transaction predictions."

## 20. Acknowledgements

- The Machine Learning Group at Université Libre de Bruxelles for making the credit card fraud detection benchmark dataset available.
- The open-source Python, Scikit-learn, FastAPI, React, and data visualization communities.
- Course faculty and academic guidance that helped define the problem and project scope.

---

## License

No license file was present in the supplied project archive. Before publishing, choose a license that matches your intentions and add a `LICENSE` file. Do not claim that the dataset is owned by this project; follow the dataset provider's terms and attribution requirements.

---

<p align="center">
  <strong>FraudShield AI</strong><br>
  Machine Learning for Understanding Credit Card Fraud Detection
</p>
